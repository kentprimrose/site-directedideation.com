# Directed Ideation

Source for the [Directed Ideation site](https://directed-ideation.krose555019.chatgpt.site).

## Files

- `dist/index.html` — complete, self-contained website (HTML and CSS).
- `.openai/hosting.json` — Sites project identity and static hosting configuration.

## Work locally

Open `dist/index.html` in a browser, or run this from the project root:

```sh
python3 -m http.server 8000 --directory dist
```

Then visit `http://localhost:8000`. No dependencies or build step are required.

## Start a GitHub repository

Extract this archive, change into the `directed-ideation` directory, and run:

```sh
git init
git add .
git commit -m "Initial Directed Ideation site"
```

Create an empty repository on GitHub, then add its URL and push:

```sh
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/directed-ideation.git
git push -u origin main
```

The `.openai/hosting.json` file identifies the existing Sites project. Keep it if you want to continue editing and publishing that Site from this source. The archive excludes Git history, credentials, and temporary deployment packages.
